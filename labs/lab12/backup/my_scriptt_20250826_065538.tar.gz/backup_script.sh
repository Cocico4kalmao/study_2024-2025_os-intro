#!/bin/bash

tar -czf ~/backup/my_scriptt_$(date +%Y%m%d_%H%M%S).tar.gz "$0"

echo "Готово"
